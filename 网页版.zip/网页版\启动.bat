@echo off
chcp 65001 >nul
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 goto NONODE

node server.js
goto :EOF

:NONODE
echo.
echo  [提示] 没有找到 Node.js，将以文件方式直接打开。
echo         手动点选可以正常用，但「截图识别」不可用。
echo.
start "" "index.html"
