/* ============================================================
 * OCR 图像预处理核心：从截图里定位「深色词条块」，裁切、二值化、拼成一张干净的图
 * 纯数组运算，浏览器和 Node 都能用
 * ============================================================ */
(function (root) {
  'use strict';

  function toGray(rgba, w, h) {
    const g = new Uint8Array(w * h);
    for (let i = 0, p = 0; i < w * h; i++, p += 4) {
      g[i] = (rgba[p] * 0.299 + rgba[p + 1] * 0.587 + rgba[p + 2] * 0.114) | 0;
    }
    return g;
  }

  function otsu(g) {
    const hist = new Array(256).fill(0);
    for (let i = 0; i < g.length; i++) hist[g[i]]++;
    const total = g.length;
    let sum = 0;
    for (let i = 0; i < 256; i++) sum += i * hist[i];
    let sumB = 0, wB = 0, best = 128, bestVar = -1;
    for (let t = 0; t < 256; t++) {
      wB += hist[t];
      if (!wB) continue;
      const wF = total - wB;
      if (!wF) break;
      sumB += t * hist[t];
      const mB = sumB / wB, mF = (sum - sumB) / wF;
      const v = wB * wF * (mB - mF) * (mB - mF);
      if (v > bestVar) { bestVar = v; best = t; }
    }
    return best;
  }

  /** 缩小到 maxW 宽以内（按整数倍做盒式平均） */
  function downscale(g, w, h, maxW) {
    if (w <= maxW) return { g: g, w: w, h: h, f: 1 };
    const f = Math.ceil(w / maxW);
    const nw = Math.floor(w / f), nh = Math.floor(h / f);
    const out = new Uint8Array(nw * nh);
    for (let y = 0; y < nh; y++) {
      for (let x = 0; x < nw; x++) {
        let s = 0;
        for (let j = 0; j < f; j++) {
          const row = (y * f + j) * w + x * f;
          for (let i = 0; i < f; i++) s += g[row + i];
        }
        out[y * nw + x] = (s / (f * f)) | 0;
      }
    }
    return { g: out, w: nw, h: nh, f: f };
  }

  /**
   * 找深色圆角块（词条按钮）
   * @returns {Array<{x:number,y:number,w:number,h:number}>} 坐标基于传入的 g
   */
  function detectChips(g, w, h, opts) {
    const o = Object.assign(
      { dark: 105, minW: 24, minH: 12, maxW: 460, maxH: 110, aspect: [1.15, 7.5], fill: 0.55, lightMin: 0.03, lightMax: 0.55, maxChips: 14 },
      opts || {}
    );

    const mask = new Uint8Array(w * h);
    for (let i = 0; i < w * h; i++) if (g[i] < o.dark) mask[i] = 1;

    const seen = new Uint8Array(w * h);
    const boxes = [];
    const stack = new Int32Array(w * h);

    for (let start = 0; start < w * h; start++) {
      if (!mask[start] || seen[start]) continue;

      let sp = 0;
      stack[sp++] = start;
      seen[start] = 1;

      let minX = w, maxX = -1, minY = h, maxY = -1, area = 0;

      while (sp > 0) {
        const p = stack[--sp];
        const x = p % w, y = (p / w) | 0;
        area++;
        if (x < minX) minX = x;
        if (x > maxX) maxX = x;
        if (y < minY) minY = y;
        if (y > maxY) maxY = y;

        if (x > 0 && mask[p - 1] && !seen[p - 1]) { seen[p - 1] = 1; stack[sp++] = p - 1; }
        if (x + 1 < w && mask[p + 1] && !seen[p + 1]) { seen[p + 1] = 1; stack[sp++] = p + 1; }
        if (y > 0 && mask[p - w] && !seen[p - w]) { seen[p - w] = 1; stack[sp++] = p - w; }
        if (y + 1 < h && mask[p + w] && !seen[p + w]) { seen[p + w] = 1; stack[sp++] = p + w; }
      }

      const bw = maxX - minX + 1;
      const bh = maxY - minY + 1;
      if (bw < o.minW || bh < o.minH || bw > o.maxW || bh > o.maxH) continue;

      const asp = bw / bh;
      if (asp < o.aspect[0] || asp > o.aspect[1]) continue;

      const fill = area / (bw * bh);
      if (fill < o.fill) continue;

      // 块内亮像素（文字）占比
      let light = 0;
      for (let y = minY; y <= maxY; y++) {
        const row = y * w;
        for (let x = minX; x <= maxX; x++) if (g[row + x] > 175) light++;
      }
      const lr = light / (bw * bh);
      if (lr < o.lightMin || lr > o.lightMax) continue;

      boxes.push({ x: minX, y: minY, w: bw, h: bh, area: area, fill: fill });
    }

    boxes.sort((a, b) => b.area - a.area);
    return boxes.slice(0, o.maxChips);
  }

  /** 把选中的块裁出来统一高度，二值化成白底黑字，竖着拼成一张图 */
  function buildComposite(g, w, h, chips, opts) {
    const o = Object.assign({ targetH: 110, gap: 26, margin: 34, insetX: 0.10, insetY: 0.16 }, opts || {});
    if (!chips.length) return null;

    const parts = chips.map((c) => {
      const ix = Math.max(1, Math.round(c.w * o.insetX));
      const iy = Math.max(1, Math.round(c.h * o.insetY));
      const sx = Math.min(w - 2, c.x + ix);
      const sy = Math.min(h - 2, c.y + iy);
      const sw = Math.max(2, Math.min(w - sx, c.w - 2 * ix));
      const sh = Math.max(2, Math.min(h - sy, c.h - 2 * iy));
      const scale = o.targetH / sh;
      return { sx: sx, sy: sy, sw: sw, sh: sh, ow: Math.max(8, Math.round(sw * scale)), oh: o.targetH };
    });

    const compW = Math.max.apply(null, parts.map((p) => p.ow)) + o.margin * 2;
    const compH = parts.reduce((a, p) => a + p.oh, 0) + o.gap * (parts.length - 1) + o.margin * 2;
    const out = new Uint8Array(compW * compH).fill(255);

    let oy = o.margin;
    const rows = [];
    parts.forEach((p, idx) => {
      // 最近邻放大灰度
      const crop = new Uint8Array(p.ow * p.oh);
      for (let j = 0; j < p.oh; j++) {
        const sy2 = p.sy + Math.min(p.sh - 1, Math.floor((j / p.oh) * p.sh));
        for (let i = 0; i < p.ow; i++) {
          const sx2 = p.sx + Math.min(p.sw - 1, Math.floor((i / p.ow) * p.sw));
          crop[j * p.ow + i] = g[sy2 * w + sx2];
        }
      }
      const t = otsu(crop);
      let darkCount = 0;
      for (let k = 0; k < crop.length; k++) if (crop[k] < t) darkCount++;
      const bgDark = darkCount > crop.length / 2; // 块本身是深色底

      const ox = o.margin + Math.floor((compW - o.margin * 2 - p.ow) / 2);
      for (let j = 0; j < p.oh; j++) {
        for (let i = 0; i < p.ow; i++) {
          const v = crop[j * p.ow + i];
          const isDark = v < t;
          const isText = bgDark ? !isDark : isDark;
          out[(oy + j) * compW + ox + i] = isText ? 0 : 255;
        }
      }
      rows.push({ index: idx, y: oy, h: p.oh });
      oy += p.oh + o.gap;
    });

    return { g: out, w: compW, h: compH, rows: rows };
  }

  const API = { toGray, otsu, downscale, detectChips, buildComposite };
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
  if (typeof window !== 'undefined') window.OCRCore = API;
})(typeof window !== 'undefined' ? window : globalThis);
