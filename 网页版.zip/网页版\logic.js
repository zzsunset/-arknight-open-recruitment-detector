/* ============================================================
 * 明日方舟 · 公招保底逻辑（纯数据 + 纯函数，可在 Node 里单独测试）
 * ============================================================ */
(function (root) {
  'use strict';

  /* ---------- 1. 标签池（29 个，去掉「元素 / 支援机械」后 27 个） ---------- */
  const GROUPS = [
    { name: '资历', tags: ['高级资深干员', '资深干员', '新手'] },
    { name: '职业', tags: ['先锋', '近卫', '狙击', '重装', '医疗', '辅助', '术师', '特种'] },
    { name: '位置', tags: ['近战位', '远程位'] },
    { name: '词缀', tags: ['控场', '爆发', '治疗', '支援', '费用回复', '输出', '生存', '群攻', '防护', '减速', '削弱', '快速复活', '位移', '召唤'] },
  ];

  const ALL_TAGS = GROUPS.reduce((acc, g) => acc.concat(g.tags), []);
  const TAG_ORDER = new Map(ALL_TAGS.map((t, i) => [t, i]));

  /* ---------- 2. 保底数据库 ----------
   * 4★：单标签 8 组 + 双标签 17 组 = 25 组
   * 5★：双标签 39 组 + 三标签 4 组 = 43 组
   * 数据来源：PRTS 公招计算（页面最后更新 2026-10-06）
   */
  const GUARANTEE_DB = {
    4: [
      // ---- 单标签 ----
      ['召唤'], ['爆发'], ['位移'], ['快速复活'], ['控场'], ['削弱'], ['支援'], ['特种'],
      // ---- 双标签 ----
      ['辅助', '近战位'],
      ['先锋', '远程位'],
      ['辅助', '治疗'],
      ['先锋', '治疗'],
      ['远程位', '费用回复'],
      ['治疗', '费用回复'],
      ['狙击', '生存'],
      ['辅助', '防护'],
      ['近卫', '减速'],
      ['远程位', '生存'],
      ['输出', '群攻'],
      ['术师', '减速'],
      ['近战位', '减速'],
      ['治疗', '减速'],
      ['群攻', '减速'],
      ['狙击', '减速'],
      ['输出', '减速'],
    ],
    5: [
      // ---- 双标签 39 组 ----
      ['狙击', '爆发'], ['术师', '爆发'], ['术师', '治疗'], ['控场', '费用回复'], ['辅助', '输出'],
      ['治疗', '输出'], ['重装', '生存'], ['辅助', '生存'], ['支援', '生存'], ['爆发', '群攻'],
      ['近卫', '防护'], ['术师', '防护'], ['远程位', '防护'], ['生存', '防护'], ['群攻', '防护'],
      ['特种', '减速'], ['控场', '减速'], ['特种', '削弱'], ['近战位', '削弱'], ['削弱', '快速复活'],
      ['重装', '位移'], ['输出', '位移'], ['防护', '位移'], ['减速', '位移'], ['辅助', '召唤'],
      ['控场', '召唤'], ['辅助', '控场'], ['特种', '控场'], ['先锋', '控场'], ['远程位', '爆发'],
      ['先锋', '支援'], ['支援', '费用回复'], ['特种', '生存'], ['辅助', '削弱'], ['群攻', '削弱'],
      ['控场', '快速复活'], ['重装', '输出'], ['近战位', '控场'], ['输出', '防护'],
      // ---- 三标签 4 组 ----
      ['辅助', '远程位', '支援'],
      ['近卫', '输出', '群攻'],
      ['近战位', '输出', '群攻'],
      ['术师', '输出', '减速'],
    ],
  };

  /** 特殊标签：出现即锁定星级 */
  const SPECIAL = { '高级资深干员': 6, '资深干员': 5 };

  /** 组合 → 星级的索引，key 为规范化后的组合串 */
  const KEY = (tags) =>
    tags
      .slice()
      .sort((a, b) => (TAG_ORDER.get(a) ?? 99) - (TAG_ORDER.get(b) ?? 99))
      .join('+');

  const DB_MAP = new Map();
  Object.keys(GUARANTEE_DB).forEach((star) => {
    GUARANTEE_DB[star].forEach((combo) => DB_MAP.set(KEY(combo), Number(star)));
  });

  /* ---------- 3. 判定 ---------- */
  function combinations(arr, k) {
    const out = [];
    (function walk(start, cur) {
      if (cur.length === k) { out.push(cur.slice()); return; }
      for (let i = start; i < arr.length; i++) {
        cur.push(arr[i]);
        walk(i + 1, cur);
        cur.pop();
      }
    })(0, []);
    return out;
  }

  /**
   * @param {Iterable<string>} tags 本次招募出现的词条（最多 5 个）
   * @returns {{max:number, hits:Array<{tags:string[], star:number, special?:boolean}>}}
   */
  function evaluate(tags) {
    const list = Array.from(new Set(tags)).slice(0, 5);
    const hits = [];

    // 特殊标签：高资 = 6★，资深 = 5★
    list.forEach((t) => {
      if (SPECIAL[t]) hits.push({ tags: [t], star: SPECIAL[t], special: true });
    });

    // 普通组合：1~3 个标签
    const maxK = Math.min(3, list.length);
    for (let k = 1; k <= maxK; k++) {
      for (const combo of combinations(list, k)) {
        const star = DB_MAP.get(KEY(combo));
        if (star) hits.push({ tags: combo, star });
      }
    }

    hits.sort((a, b) => b.star - a.star || a.tags.length - b.tags.length);
    const max = hits.reduce((m, h) => Math.max(m, h.star), 0);
    return { max, hits };
  }

  /* ---------- 4. 截图识别的模糊匹配 ---------- */
  /** 去掉空格/标点，并吃掉「干员」后缀：高级资深干员 → 高级资深 */
  function normalizeTag(s) {
    return String(s)
      .replace(/[\s\u3000·・．.,，。:：;；|/\\_\-—–"'“”‘’()（）\[\]【】]/g, '')
      .replace(/干员$/, '');
  }

  function lev(a, b) {
    const m = a.length, n = b.length;
    if (!m) return n;
    if (!n) return m;
    let prev = new Array(n + 1);
    let cur = new Array(n + 1);
    for (let j = 0; j <= n; j++) prev[j] = j;
    for (let i = 1; i <= m; i++) {
      cur[0] = i;
      for (let j = 1; j <= n; j++) {
        const cost = a[i - 1] === b[j - 1] ? 0 : 1;
        cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost);
      }
      const tmp = prev; prev = cur; cur = tmp;
    }
    return prev[n];
  }

  /** 把 OCR 出来的每一行匹配到标签池里的词条 */
  function matchTags(lines, limit) {
    const scored = [];
    for (const raw of lines) {
      const line = normalizeTag(raw);
      if (line.length < 2) continue;

      let best = null;
      for (const tag of ALL_TAGS) {
        const n = normalizeTag(tag);
        let sc = 0;
        if (line === n) sc = 1;
        else if (line.includes(n)) sc = 0.95;
        else {
          let d;
          if (line.length > n.length) {
            d = Infinity;
            for (let i = 0; i + n.length <= line.length; i++) {
              d = Math.min(d, lev(line.slice(i, i + n.length), n));
            }
            sc = 1 - d / n.length;
          } else {
            d = lev(line, n);
            sc = 1 - d / Math.max(line.length, n.length);
          }
        }
        if (!best || sc > best.score) best = { tag, score: sc };
      }

      const need = line.length <= 2 ? 0.5 : 0.62;
      if (best && best.score >= need) scored.push({ tag: best.tag, score: best.score, raw });
    }

    const map = new Map();
    scored.forEach((s) => {
      const cur = map.get(s.tag);
      if (!cur || cur.score < s.score) map.set(s.tag, s);
    });
    return Array.from(map.values())
      .sort((a, b) => b.score - a.score)
      .slice(0, limit || 5);
  }

  /** 从一段文字里扒出词条（长的优先，支持「干员」后缀） */
  function parseTags(text) {
    const t = String(text || '').replace(/\s+/g, '');
    const names = ALL_TAGS.map((n) => ({ full: n, short: n.replace(/干员$/, '') })).sort(
      (a, b) => b.short.length - a.short.length
    );
    const out = [];
    let i = 0;
    while (i < t.length) {
      let hit = null;
      for (const n of names) {
        if (t.startsWith(n.full, i)) { hit = { tag: n.full, len: n.full.length }; break; }
        if (n.short !== n.full && t.startsWith(n.short, i)) { hit = { tag: n.full, len: n.short.length }; break; }
      }
      if (hit) {
        if (out.indexOf(hit.tag) < 0) out.push(hit.tag);
        i += hit.len;
      } else {
        i++;
      }
    }
    return out.slice(0, 5);
  }

  const API = { GROUPS, ALL_TAGS, GUARANTEE_DB, DB_MAP, SPECIAL, KEY, evaluate, combinations, normalizeTag, lev, matchTags, parseTags };

  if (typeof module !== 'undefined' && module.exports) module.exports = API;
  if (typeof window !== 'undefined') window.HR = API;
  root.HR = root.HR || API;
})(typeof window !== 'undefined' ? window : globalThis);
