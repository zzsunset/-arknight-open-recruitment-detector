/* ============================================================
 * 明日方舟 · 公招保底查询 —— 页面交互 + 截图识别
 * 识别思路：先找出深色词条块 → 逐块二值化拼图 → OCR → 模糊匹配到标签池
 * ============================================================ */
(function () {
  'use strict';

  const HR = window.HR;
  const OC = window.OCRCore;
  const MAX_PICK = 5;
  const state = { selected: new Set() };

  const $ = (id) => document.getElementById(id);

  /* ---------------- 选词条 ---------------- */
  function buildGroups() {
    const wrap = $('groups');
    wrap.innerHTML = '';
    HR.GROUPS.forEach((group) => {
      const row = document.createElement('div');
      row.className = 'group';

      const name = document.createElement('div');
      name.className = 'group-name';
      name.textContent = group.name;

      const chips = document.createElement('div');
      chips.className = 'chips';

      group.tags.forEach((tag) => {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'chip';
        btn.dataset.tag = tag;
        btn.textContent = tag;
        btn.setAttribute('aria-pressed', 'false');
        if (tag === '新手') {
          btn.classList.add('muted');
          btn.title = '新手只会出 2 星';
        }
        btn.addEventListener('click', () => toggleTag(tag));
        chips.appendChild(btn);
      });

      row.appendChild(name);
      row.appendChild(chips);
      wrap.appendChild(row);
    });
  }

  function toggleTag(tag) {
    if (state.selected.has(tag)) {
      state.selected.delete(tag);
    } else {
      if (state.selected.size >= MAX_PICK) {
        toast('最多只能选 5 个词条（一次招募只给 5 个）');
        return;
      }
      state.selected.add(tag);
    }
    sync();
  }

  function sync() {
    document.querySelectorAll('.chip').forEach((btn) => {
      const on = state.selected.has(btn.dataset.tag);
      btn.classList.toggle('on', on);
      btn.setAttribute('aria-pressed', on ? 'true' : 'false');
    });
    $('counter').textContent = state.selected.size + ' / ' + MAX_PICK;
    renderResult();
  }

  /* ---------------- 结果 ---------------- */
  function renderResult() {
    const body = $('resultBody');

    if (!state.selected.size) {
      body.innerHTML = '<div class="empty">勾选词条后，这里会立刻显示最高保底星级。</div>';
      return;
    }

    const { max, hits } = HR.evaluate(state.selected);

    if (!max) {
      body.innerHTML =
        '<div class="empty">这组词条<b>没有 4★ 及以上的保底</b>，最差可能出 3★。<br>' +
        '（保底 = 选中这些词条后，池子里最低的星级）</div>';
      return;
    }

    const starName = { 6: '6 星', 5: '5 星', 4: '4 星' }[max];
    const hitHtml = hits
      .map(
        (h) =>
          '<div class="hit ' + (h.star === max ? 'top' : '') + '">' +
          '<span class="hs hs' + h.star + '">' + h.star + '★</span>' +
          '<span class="combo">' + h.tags.join(' + ') + '</span>' +
          (h.special ? '<span class="badge">特殊标签</span>' : '') +
          '</div>'
      )
      .join('');

    body.innerHTML =
      '<div class="verdict" data-star="' + max + '">' +
      '<div class="vs-star">' + max + '★</div>' +
      '<div class="vs-text">保底 ' + starName + '</div>' +
      '<div class="vs-sub">共 ' + hits.length + ' 个组合达到</div>' +
      '</div>' +
      '<div class="hits">' + hitHtml + '</div>';
  }

  /* ---------------- 数据库展示 ---------------- */
  function renderDB() {
    const body = $('dbBody');
    let html = '<div class="db-line"><span class="k">6★</span>高级资深干员（单标签必出）</div>';
    [5, 4].forEach((star) => {
      const list = HR.GUARANTEE_DB[star] || [];
      html +=
        '<div class="db-line"><span class="k">' + star + '★</span>' +
        list.map((c) => c.join('+')).join('、') +
        '</div>';
    });
    html += '<div class="db-line"><span class="k">5★</span>资深干员（单标签必出）</div>';
    body.innerHTML = html;
  }

  /* ---------------- 小提示 ---------------- */
  let toastTimer = null;
  function toast(msg) {
    const el = $('toast');
    el.textContent = msg;
    el.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.classList.remove('show'), 1900);
  }

  function setStatus(text, kind) {
    const el = $('ocrStatus');
    el.textContent = text || '';
    el.className = 'ocr-status' + (kind ? ' ' + kind : '');
  }

  /* ---------------- OCR 引擎 ---------------- */
  const ocr = { libPromise: null, workerPromise: null };

  function ensureLib() {
    if (window.Tesseract) return Promise.resolve();
    if (ocr.libPromise) return ocr.libPromise;
    ocr.libPromise = new Promise((resolve, reject) => {
      const s = document.createElement('script');
      s.src = 'https://cdn.jsdelivr.net/npm/tesseract.js@5.1.1/dist/tesseract.min.js';
      s.onload = () => resolve();
      s.onerror = () => reject(new Error('识别引擎加载失败，请检查网络'));
      document.head.appendChild(s);
    });
    return ocr.libPromise;
  }

  function getWorker() {
    if (!ocr.workerPromise) {
      setStatus('首次使用需要下载中文模型（约 20MB），请稍等…');
      ocr.workerPromise = window.Tesseract.createWorker('chi_sim', 1, {
        logger: (m) => {
          if (!m) return;
          if (m.status === 'recognizing text') {
            setStatus('识别中… ' + Math.round((m.progress || 0) * 100) + '%');
          } else if (m.status && m.status.indexOf('load language') >= 0) {
            setStatus('正在载入中文模型…');
          }
        },
      });
    }
    return ocr.workerPromise;
  }

  async function ocrCanvas(canvas, psm) {
    const worker = await getWorker();
    await worker.setParameters({ tessedit_pageseg_mode: String(psm) });
    const { data } = await worker.recognize(canvas);
    return (data.text || '')
      .split(/\r?\n/)
      .map((s) => s.trim())
      .filter(Boolean);
  }

  /* ---------------- 图像处理 ---------------- */

  function canvasFromImage(img) {
    const w = img.naturalWidth || img.width;
    const h = img.naturalHeight || img.height;
    const c = document.createElement('canvas');
    c.width = w;
    c.height = h;
    c.getContext('2d', { willReadFrequently: true }).drawImage(img, 0, 0);
    return c;
  }

  function grayFromCanvas(c) {
    const ctx = c.getContext('2d', { willReadFrequently: true });
    const d = ctx.getImageData(0, 0, c.width, c.height);
    return { gray: OC.toGray(d.data, c.width, c.height), w: c.width, h: c.height };
  }

  function compositeToCanvas(comp) {
    const c = document.createElement('canvas');
    c.width = comp.w;
    c.height = comp.h;
    const ctx = c.getContext('2d', { willReadFrequently: true });
    const id = ctx.createImageData(comp.w, comp.h);
    for (let i = 0; i < comp.w * comp.h; i++) {
      const v = comp.g[i];
      id.data[i * 4] = v;
      id.data[i * 4 + 1] = v;
      id.data[i * 4 + 2] = v;
      id.data[i * 4 + 3] = 255;
    }
    ctx.putImageData(id, 0, 0);
    return c;
  }

  /** 整图二值化兜底 */
  function binarizeWhole(canvas) {
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    const id = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const d = id.data;
    const n = canvas.width * canvas.height;
    const gray = new Uint8Array(n);
    for (let i = 0; i < n; i++) gray[i] = (d[i * 4] * 0.299 + d[i * 4 + 1] * 0.587 + d[i * 4 + 2] * 0.114) | 0;
    const t = OC.otsu(gray);
    let dark = 0;
    for (let i = 0; i < n; i++) if (gray[i] < t) dark++;
    const invert = dark > n / 2;
    for (let i = 0; i < n; i++) {
      const isDark = gray[i] < t;
      const v = invert ? (isDark ? 255 : 0) : (isDark ? 0 : 255);
      d[i * 4] = v; d[i * 4 + 1] = v; d[i * 4 + 2] = v; d[i * 4 + 3] = 255;
    }
    ctx.putImageData(id, 0, 0);
    return canvas;
  }

  /* ---------------- 主识别流程 ---------------- */
  async function analyze(img) {
    await ensureLib();

    const canvas = canvasFromImage(img);
    const { gray, w, h } = grayFromCanvas(canvas);

    // 1. 定位深色词条块
    const ds = OC.downscale(gray, w, h, 900);
    let chips = OC.detectChips(ds.g, ds.w, ds.h)
      .map((c) => ({
        x: Math.round(c.x * ds.f),
        y: Math.round(c.y * ds.f),
        w: Math.round(c.w * ds.f),
        h: Math.round(c.h * ds.f),
      }))
      .filter((c) => c.x >= 0 && c.y >= 0 && c.w > 8 && c.h > 8 && c.x + c.w <= w && c.y + c.h <= h)
      .sort((a, b) => a.y - b.y || a.x - b.x)
      .slice(0, 10);

    let tags = [];

    if (chips.length) {
      setStatus('找到 ' + chips.length + ' 个词条块，正在识别…');
      const comp = OC.buildComposite(gray, w, h, chips, {});
      const lines = await ocrCanvas(compositeToCanvas(comp), 6);
      tags = HR.matchTags(lines, MAX_PICK);

      // 拼图识别没结果 → 逐块单独识别
      if (!tags.length) {
        for (let i = 0; i < chips.length; i++) {
          setStatus('逐块识别… ' + (i + 1) + '/' + chips.length);
          const one = OC.buildComposite(gray, w, h, [chips[i]], {});
          const l = await ocrCanvas(compositeToCanvas(one), 7);
          const m = HR.matchTags(l, 1)[0];
          if (m && !tags.some((t) => t.tag === m.tag)) tags.push(m);
        }
      }
    }

    // 2. 还是没结果 → 整图兜底
    if (!tags.length) {
      setStatus('没找到词条块，改用整图识别…');
      const whole = binarizeWhole(canvas);
      let lines = await ocrCanvas(whole, 6);
      tags = HR.matchTags(lines, MAX_PICK);
      if (!tags.length) {
        lines = await ocrCanvas(whole, 11);
        tags = HR.matchTags(lines, MAX_PICK);
      }
    }

    if (!tags.length) {
      setStatus('没能认出词条。可以换一张更清晰的截图，或直接手动点选（也可以在输入框里打词条）。', 'warn');
      return;
    }

    state.selected.clear();
    tags.slice(0, MAX_PICK).forEach((t) => state.selected.add(t.tag));
    sync();
    setStatus('识别到 ' + tags.length + ' 个词条：' + tags.map((t) => t.tag).join('、') + '（已选中，有错请手动改）', 'ok');
  }

  /* ---------------- 图片输入 ---------------- */
  function showPreview(img) {
    const p = $('preview');
    p.hidden = false;
    p.width = img.naturalWidth || img.width;
    p.height = img.naturalHeight || img.height;
    p.getContext('2d').drawImage(img, 0, 0);
  }

  function clearShot() {
    const p = $('preview');
    p.hidden = true;
    p.width = 1;
    p.height = 1;
    setStatus('');
    $('pasteInput').value = '';
  }

  function handleFile(file) {
    if (!file || !/^image\//.test(file.type)) {
      setStatus('这不是图片文件。', 'warn');
      return;
    }
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      showPreview(img);
      URL.revokeObjectURL(url);
      analyze(img).catch((err) => {
        setStatus('识别失败：' + (err && err.message ? err.message : err), 'err');
      });
    };
    img.onerror = () => setStatus('图片读取失败，换一张试试。', 'err');
    img.src = url;
  }

  /** 从输入框文字里扒词条 */
  function applyTextTags(text) {
    const found = HR.parseTags(text);
    if (!found.length) {
      setStatus('没从文字里认出词条，试试「近卫 医疗 新手 费用回复 输出」这样写。', 'warn');
      return;
    }
    state.selected.clear();
    found.slice(0, MAX_PICK).forEach((t) => state.selected.add(t));
    sync();
    setStatus('从文字里读到：' + found.slice(0, MAX_PICK).join('、'), 'ok');
  }

  function bindInputs() {
    const drop = $('drop');
    const fileInput = $('file');
    const pasteInput = $('pasteInput');

    $('btnPick').addEventListener('click', () => fileInput.click());
    fileInput.addEventListener('change', () => {
      if (fileInput.files && fileInput.files[0]) handleFile(fileInput.files[0]);
      fileInput.value = '';
    });

    $('btnClearShot').addEventListener('click', clearShot);

    // 拖拽
    ['dragenter', 'dragover'].forEach((ev) =>
      drop.addEventListener(ev, (e) => {
        e.preventDefault();
        drop.classList.add('over');
      })
    );
    ['dragleave', 'drop'].forEach((ev) =>
      drop.addEventListener(ev, (e) => {
        e.preventDefault();
        drop.classList.remove('over');
      })
    );
    drop.addEventListener('drop', (e) => {
      const f = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
      if (f) handleFile(f);
    });

    // 输入框：聚焦后粘贴
    pasteInput.addEventListener('paste', (e) => {
      const items = e.clipboardData && e.clipboardData.items;
      if (!items) return;
      for (const it of items) {
        if (it.type && it.type.indexOf('image/') === 0) {
          const f = it.getAsFile();
          if (f) {
            e.preventDefault();
            handleFile(f);
          }
          return;
        }
      }
      // 粘贴的是纯文本 → 延迟到默认粘贴完成后再解析
      setTimeout(() => {
        const v = pasteInput.value.trim();
        if (v) applyTextTags(v);
      }, 0);
    });

    pasteInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        applyTextTags(pasteInput.value);
      }
    });

    // 页面任意位置粘贴图片也能接住
    document.addEventListener('paste', (e) => {
      if (e.target === pasteInput) return;
      const items = e.clipboardData && e.clipboardData.items;
      if (!items) return;
      for (const it of items) {
        if (it.type && it.type.indexOf('image/') === 0) {
          const f = it.getAsFile();
          if (f) {
            e.preventDefault();
            handleFile(f);
          }
          return;
        }
      }
    });

    if (location.protocol === 'file:') {
      setStatus('提示：截图识别需要从「启动.bat」打开（file:// 下浏览器禁止后台线程）。手动点选和输入框打字不受影响。', 'warn');
    }
  }

  /* ---------------- 启动 ---------------- */
  document.addEventListener('DOMContentLoaded', () => {
    buildGroups();
    renderDB();
    bindInputs();

    const m = location.hash.match(/^#t=(.+)$/);
    if (m) {
      decodeURIComponent(m[1])
        .split(/[,+、]/)
        .map((s) => s.trim())
        .filter(Boolean)
        .forEach((t) => {
          if (HR.ALL_TAGS.indexOf(t) >= 0 && state.selected.size < MAX_PICK) state.selected.add(t);
        });
    }

    $('btnClear').addEventListener('click', () => {
      state.selected.clear();
      sync();
    });
    sync();
  });
})();
